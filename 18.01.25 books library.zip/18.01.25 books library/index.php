<?php
require 'Book.php';
require 'Reader.php';
require 'Library.php';

$library = new Library();
$library->addBook(new Book("Гарри Поттер", "Джоан Роулинг", 1997));
$library->addBook(new Book("Война и мир", "Лев Толстой", 1869));

$reader1 = new Reader("Иван Иванов", "ivan@example.com");
$library->addReader($reader1);

$library->listBooks(); 
$reader1->borrowBook($library->findBook("1984")); 
$library->listBooks(); 
$reader1->returnBook($library->findBook("1984"));
$library->listBooks(); 

?>