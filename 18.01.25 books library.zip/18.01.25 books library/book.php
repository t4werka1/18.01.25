<?php
class Book {
    private $title, $author, $year, $isAvailable = true;

    public function __construct($title, $author, $year) {
        $this->title = $title;
        $this->author = $author;
        $this->year = $year;
    }

    public function getTitle() { return $this->title; }
    public function getAuthor() { return $this->author; }
    public function getYear() { return $this->year; }
    public function isAvailable() { return $this->isAvailable; }
    public function setAvailability($status) { $this->isAvailable = $status; }
}
?>