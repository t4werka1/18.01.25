<?php
class Library {
    private $books = [], $readers = [];

    public function addBook($book) { 
        $this->books[] = $book; 
        echo "Книга '{$book->getTitle()}' добавлена.\n"; 
    }

    public function addReader($reader) { 
        $this->readers[] = $reader; 
        echo "Читатель '{$reader->getName()}' добавлен.\n"; 
    }

    public function listBooks() {
        foreach ($this->books as $book) {
            echo "- '{$book->getTitle()}' автор: {$book->getAuthor()} (Год: {$book->getYear()})" . ($book->isAvailable() ? " [Доступна]" : " [Недоступна]") . "\n";
        }
    }

    public function findBook($title) {
        foreach ($this->books as $book) {
            if ($book->getTitle() === $title) return $book;
        }
        return null;
    }
}
?>