<?php
class Reader {
    private $name, $email, $borrowedBooks = [];

    public function __construct($name, $email) {
        $this->name = $name;
        $this->email = $email;
    }

    public function getName() { return $this->name; }

    public function borrowBook($book) {
        if ($book && $book->isAvailable()) {
            $this->borrowedBooks[] = $book;
            $book->setAvailability(false);
            echo "{$this->name} взял '{$book->getTitle()}'.\n";
        } else {
            echo "Книга недоступна или не найдена.\n";
        }
    }

    public function returnBook($book) {
        if (($key = array_search($book, $this->borrowedBooks, true)) !== false) {
            unset($this->borrowedBooks[$key]);
            $book->setAvailability(true);
            echo "{$this->name} вернул '{$book->getTitle()}'.\n";
        }
    }
}
?>